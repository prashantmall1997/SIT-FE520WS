from flask import Blueprint, render_template, request
import time
import psycopg2
from io import StringIO
import pandas as pd
import yfinance as yf

con = psycopg2.connect(database="FE520", host="localhost", port="5432")
cursor = con.cursor()

views = Blueprint("views", __name__)


@views.route("/", methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        stockName = request.form.get('myStock')

        df = pd.read_csv("StockList.csv")
        stockInfo = (df.loc[df['Symbol'] == stockName])
        if(stockInfo.empty == False):
            stockInfoObj = {
                "Name": stockInfo['Name'].to_string(index=False),
                "Country": stockInfo['Country'].to_string(index=False),
                "IPO Year": stockInfo['IPO Year'].to_string(index=False),
                "Sector": stockInfo['Sector'].to_string(index=False),
                "Industry": stockInfo['Industry'].to_string(index=False)
            }
            return render_template('home.html', stockName=stockName, stockInfoObj=stockInfoObj)
        else:
            df = pd.read_csv("StockList.csv")
            stockInfo = (df.loc[df['Symbol'] == "AMZN"])
            stockInfoObj = {
                "Name": stockInfo['Name'].to_string(index=False),
                "Country": stockInfo['Country'].to_string(index=False),
                "IPO Year": stockInfo['IPO Year'].to_string(index=False),
                "Sector": stockInfo['Sector'].to_string(index=False),
                "Industry": stockInfo['Industry'].to_string(index=False)
            }
            alert = "True"
            return render_template("home.html", stockName="AMZN", stockInfoObj=stockInfoObj, alert=alert)
    else:
        df = pd.read_csv("StockList.csv")
        stockInfo = (df.loc[df['Symbol'] == "AMZN"])
        stockInfoObj = {
            "Name": stockInfo['Name'].to_string(index=False),
            "Country": stockInfo['Country'].to_string(index=False),
            "IPO Year": stockInfo['IPO Year'].to_string(index=False),
            "Sector": stockInfo['Sector'].to_string(index=False),
            "Industry": stockInfo['Industry'].to_string(index=False)
        }
        return render_template("home.html", stockName="AMZN", stockInfoObj=stockInfoObj)


@views.route('/stockdata', methods=["GET", "POST"])
def pipe():
    stockName = request.args.get('stockName').lower()

    cursor.execute(
        f"SELECT tablename FROM pg_tables WHERE schemaname = 'public'")
    result = list(cursor.fetchall())
    stockExsistList = []
    for i in range(len(result)):
        result[i] = list(result[i])
        stockExsistList += result[i]
    if stockName in stockExsistList:
        cursor.execute(f"select * from {stockName}")
        result = list(cursor.fetchall())

        for i in range(len(result)):
            result[i] = list(result[i])
            result[i][0] = (time.mktime(result[i][0].timetuple()))*1000
            result[i] = [int(x) for x in result[i]]

        return {"res": result}

    else:
        df = yf.download(stockName)
        df.drop('Adj Close', inplace=True, axis=1)

        df.index.name = 'Date'
        df.reset_index(inplace=True)

        # Initialize a string buffer
        sio = StringIO()
        # Write the Pandas DataFrame as a CSV to the buffer
        sio.write(df.to_csv(index=None, header=None))
        # Be sure to reset the position to the start of the stream
        sio.seek(0)
        # Rename column names to match DB Table
        df.rename(columns={'Date': 'date', 'Open': 'open', 'High': 'high', 'Low': 'low',
                           'Close': 'close', 'Volume': 'volume'}, inplace=True)

        # Copy the String Buffer to the DB (Like if an actual file)
        with con.cursor() as c:
            c.execute(
                f"CREATE TABLE {stockName} (Date DATE, Open NUMERIC, High NUMERIC, Low NUMERIC, Close NUMERIC, Volume NUMERIC);")
            c.copy_from(sio, stockName, columns=df.columns, sep=',')
            con.commit()

        # Fetch and return data
        cursor.execute(f"select * from {stockName}")
        result = list(cursor.fetchall())

        for i in range(len(result)):
            result[i] = list(result[i])
            result[i][0] = (time.mktime(result[i][0].timetuple()))*1000
            result[i] = [int(x) for x in result[i]]

        return {"res": result}
