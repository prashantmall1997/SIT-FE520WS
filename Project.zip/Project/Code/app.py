from website import create_app
import os

# Clear Console
def clearConsole():
    command = 'clear'
    if os.name in ('nt', 'dos'):
        command = 'cls'
    os.system(command)


clearConsole()

if __name__ == "__main__":
    app = create_app()
    app.run(debug=False)
